import { Component } from '@angular/core';
import { Header } from '../../components/header/header';

@Component({
  selector: 'app-gestion',
  imports: [Header],
  templateUrl: './gestion.html',
  styleUrl: './gestion.css',
})
export class Gestion {
  public active: string = 'gestion';

}
