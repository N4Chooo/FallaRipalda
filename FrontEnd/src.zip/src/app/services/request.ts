import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { catchError, map, of, tap, Observable } from 'rxjs';


@Injectable({
  providedIn: 'root',
})
export class Request {
  private http = inject(HttpClient);
  private router = inject(Router);
  private user = "http://127.0.0.1:8000/api/register";
  private falleros = "http://127.0.0.1:8000/api/participants";  //se puede filtrar por status(pagado o pendiente), rol,dni o category
  private fallas26 = "http://127.0.0.1:8000/api/monuments?year=2026";
  private fallas = "http://127.0.0.1:8000/api/monuments";//se puede filtrar por year
  private llibret = "http://127.0.0.1:8000/api/books";  //se puede filtrar por year
  private events = "http://127.0.0.1:8000/api/events";  //se puede filtrar por month
  private fees = "http://127.0.0.1:8000/api/fees";
  private users = "http://127.0.0.1:8000/api/user";
  private sponsors = "http://127.0.0.1:8000/api/sponsors";
  private loginApi = "http://127.0.0.1:8000/api/login";
  public userName = '';

  public createUser(userData: any): Observable<any> {
    return this.http.post<any>(this.user, userData);
  }

  public getInfo(): Observable<any> {
    return this.http.get<any>(this.falleros);
  }

  public getUsers(): Observable<any> {
    return this.http.get<any>(this.users);
  }

  private readonly AUTH_KEY = 'user_auth';

  public login(user: string, pass: string) {
    this.userName = user;
    const authString = btoa(`${user}:${pass}`);

    const headers = new HttpHeaders({
      Authorization: `Basic ${authString}`
    });

    return this.http.get<any>(`${this.loginApi}`, { headers }).pipe(
      tap((response) => {
        localStorage.setItem(this.AUTH_KEY, authString);
        if (response.roles) {
          localStorage.setItem('user_roles', JSON.stringify(response.roles));
        }
        if (response.user) {
          localStorage.setItem('user_name', response.user);
        }
      })
    );
  }
  public getUsername() {
    return this.userName;
  }

  public isLoggedIn(): boolean {
    return !!localStorage.getItem(this.AUTH_KEY);
  }

  public hasRole(role: string): boolean {
    const rolesRaw = localStorage.getItem('user_roles');
    if (!rolesRaw) return false;

    const roles: string[] = JSON.parse(rolesRaw);
    return roles.includes(role);
  }

  public getAuthString(): string | null {
    return localStorage.getItem(this.AUTH_KEY);
  }

  public logout() {
    localStorage.removeItem(this.AUTH_KEY);
    this.router.navigate(['/index']);
  }


  public getMonuments2026(): Observable<any> {
    return this.http.get<any>(this.fallas26)
  }

  public getMonuments(): Observable<any> {
    return this.http.get<any>(this.fallas)
  }
 
  public getEvents(month: string): Observable<any> {
    if (month == ''){
      return this.http.get<any>(this.events);
    }
    else{
      console.log(`${this.events}?year=${month}`)
      return this.http.get<any>(`${this.events}?month=${month}`);
    }
    
  }
}
